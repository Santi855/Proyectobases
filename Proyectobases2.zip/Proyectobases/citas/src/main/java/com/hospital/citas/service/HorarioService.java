package com.hospital.citas.service;

import com.hospital.citas.model.Doctor;
import com.hospital.citas.repository.CitaRepository;
import com.hospital.citas.repository.DoctorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class HorarioService {


}

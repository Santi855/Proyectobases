package com.hospital.citas.controller;

import com.hospital.citas.service.RecetaService;
import com.hospital.citas.service.CitaService; // Necesario para la tarea de filtrar citas
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List; // Importar List<>

@Controller
@RequestMapping("/doctor")
public class DoctorController {

    @Autowired
    private RecetaService recetaService;

    @Autowired
    private CitaService citaService; // Inyección para la tarea de filtrar citas

    // ====================================================================
    // 1. GENERAR RECETA (URL: /doctor/formulario-receta)
    // ====================================================================

    @GetMapping("/formulario-receta")
    public String mostrarFormularioReceta(Model model) {
        // Apunta a templates/Receta/formulario-receta.html
        return "Receta/formulario-receta"; 
    }

    @PostMapping("/generar-receta")
    public String generarReceta(
        @RequestParam("citaId") Integer citaId,
        @RequestParam("doctorId") Integer doctorId,
        @RequestParam("pacienteId") Integer pacienteId,
        @RequestParam("diagnostico") String diagnostico,
        @RequestParam("tratamiento") String tratamiento,
        @RequestParam("medicamentos") String medicamentos, // Sin el campo 'duracion' separado
        Model model) {

        try {
            // Se llama al servicio con 6 argumentos, el SP valida la fecha de la cita
            Integer numReceta = recetaService.guardarNuevaReceta(
                citaId,
                doctorId,
                pacienteId,
                diagnostico,
                tratamiento,
                medicamentos
            );

            model.addAttribute("numReceta", numReceta);
            model.addAttribute("mensajeExito", "Receta N°" + numReceta + " generada con éxito.");
            
            return "confirmacion-receta"; // Vista de confirmación

        } catch (Exception e) {
            model.addAttribute("mensajeError", "Error al generar la receta: " + e.getMessage());
            return "Receta/formulario-receta"; // Vuelve al formulario con el error
        }
    }

    // ====================================================================
    // 2. MOSTRAR CITAS DEL MÉDICO (URL: /doctor/citas/dashboard)
    // ====================================================================

    @GetMapping("/citas/dashboard")
    public String mostrarDashboardCitas(
        @RequestParam("doctorId") Integer idDoctor, 
        Model model) {

        try {
            // Llama al SP_MostrarCitasPorDoctor
            List<Object[]> citas = citaService.obtenerCitasPorDoctor(idDoctor);
            
            model.addAttribute("citas", citas);
            
            // Apunta a templates/Doctor/citas-medico-tabla.html
            return "Doctor/citas-medico-tabla"; 

        } catch (Exception e) {
            model.addAttribute("error", "No se pudieron cargar las citas: " + e.getMessage());
            return "error-page"; 
        }
    }
    
    // ====================================================================
    // 3. MOSTRAR TODAS LAS RECETAS EMITIDAS (URL: /doctor/recetas/resultados)
    // ====================================================================

    @GetMapping("/recetas/buscar")
    public String mostrarFormularioBusquedaReceta() {
        return "Doctor/buscar-recetas-form"; 
    }

    @GetMapping("/recetas/resultados")
    public String mostrarResultadosRecetas(
        @RequestParam("cedula") String cedulaMedico,
        Model model) {

        try {
            // Llama al SP_MostrarRecetasPorMedico
            List<Object[]> recetas = recetaService.obtenerRecetasPorMedico(cedulaMedico);

            if (recetas.isEmpty()) {
                model.addAttribute("mensaje", "No se encontraron recetas para la cédula " + cedulaMedico + ".");
            } else {
                model.addAttribute("recetas", recetas); 
            }
            
            // Apunta a templates/Doctor/recetas-tabla.html
            return "Doctor/recetas-tabla"; 

        } catch (Exception e) {
            model.addAttribute("error", "Error al buscar recetas: " + e.getMessage());
            return "Doctor/buscar-recetas-form"; 
        }
    }
}


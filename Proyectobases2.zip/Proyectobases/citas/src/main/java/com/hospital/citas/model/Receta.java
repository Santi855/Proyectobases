package com.hospital.citas.model;

import jakarta.persistence.*; // Usa jakarta.persistence si estás en Spring Boot 3+ (JDK 17+)
import java.util.Date; // Para el campo fecha_emision

// Anotación para indicar que esta clase es una entidad de la base de datos
@Entity
@Table(name = "Recetas") // Mapea a tu tabla dbo.Recetas
public class Receta {

    // Clave primaria (Primary Key)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Indica que el ID se genera automáticamente en la DB
    @Column(name = "id_receta")
    private Integer idReceta;

    // Claves foráneas (Foreign Keys)
    @Column(name = "id_cita")
    private Integer idCita;

    @Column(name = "id_doctor")
    private Integer idDoctor;

    @Column(name = "id_paciente")
    private Integer idPaciente;

    // Campos de texto de la receta
    @Column(name = "diagnostico")
    private String diagnostico;

    @Column(name = "tratamiento")
    private String tratamiento;

    @Column(name = "observaciones")
    private String observaciones; // Aquí guardamos los medicamentos y duración

    // Campo de fecha
    @Column(name = "fecha_emision")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaEmision;
    
    // --- Constructor vacío requerido por JPA ---
    public Receta() {}

    // --- Getters y Setters (Necesitas generarlos en VS Code) ---
    // En VS Code, haz clic derecho en el código > Source Actions (Acciones de código fuente) > Generate Getters and Setters...

    public Integer getIdReceta() {
        return idReceta;
    }

    public void setIdReceta(Integer idReceta) {
        this.idReceta = idReceta;
    }

    // [Aquí irían todos los demás Getters y Setters, generados automáticamente]
    // ...

    public Integer getIdCita() {
        return idCita;
    }

    public void setIdCita(Integer idCita) {
        this.idCita = idCita;
    }
    // ... (continúa con los demás campos)
}
package com.hospital.citas.repository;

import com.hospital.citas.model.Receta; // Asumiendo que tienes una entidad Receta
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface RecetaRepository extends JpaRepository<Receta, Integer> {

    // =================================================================
    // 1. GENERAR NUEVA RECETA (FUNCIÓN DE INSERCIÓN)
    // Se usa @Procedure porque espera un valor de retorno del SP
    // (Resuelve el problema de la duración, solo acepta 6 parámetros)
    // =================================================================
    @Procedure(procedureName = "SP_GenerarReceta")
    Integer generarReceta(
        @Param("IdCita") Integer idCita,
        @Param("IdDoctor") Integer idDoctor,
        @Param("IdPaciente") Integer idPaciente,
        @Param("Diagnostico") String diagnostico,
        @Param("Tratamiento") String tratamiento,
        @Param("Medicamentos") String medicamentos
    );

    // =================================================================
    // 2. BUSCAR RECETAS POR MÉDICO (FUNCIÓN DE LECTURA)
    // Se usa @Query(nativeQuery=true) para evitar errores de binding 
    // con el resultado del SELECT del Stored Procedure.
    // =================================================================
    @Query(value = "EXEC SP_MostrarRecetasPorMedico :CedulaMedico", nativeQuery = true)
    List<Object[]> buscarRecetasPorMedico(@Param("CedulaMedico") String cedulaMedico);
}
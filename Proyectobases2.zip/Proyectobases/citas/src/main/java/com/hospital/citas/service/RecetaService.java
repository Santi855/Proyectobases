package com.hospital.citas.service;

import com.hospital.citas.repository.RecetaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List; // Necesario para usar List<>
import org.springframework.transaction.annotation.Transactional;

@Service
public class RecetaService {

    @Autowired
    private RecetaRepository recetaRepository;

    /**
     * Llama al repositorio para ejecutar el SP de generación de receta.
     * @return El número de receta (ID) generado por la base de datos.
     */
    public Integer guardarNuevaReceta(
        Integer idCita,
        Integer idDoctor,
        Integer idPaciente,
        String diagnostico,
        String tratamiento,
        String medicamentos
    ) {

        // Llama al repositorio para ejecutar el SP y devuelve el ID generado
        Integer numRecetaGenerado = recetaRepository.generarReceta(
            idCita,
            idDoctor,
            idPaciente,
            diagnostico,
            tratamiento,
            medicamentos   
        );
        
        // Retorna el ID de la receta generada
        return numRecetaGenerado;
    }

    @Transactional(readOnly = true)
public List<Object[]> obtenerRecetasPorMedico(String cedulaMedico) {
    return (List<Object[]>) recetaRepository.buscarRecetasPorMedico(cedulaMedico);
}
}